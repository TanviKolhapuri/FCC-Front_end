# Random Quote Machine

A Pen created on CodePen.io. Original URL: [https://codepen.io/Tanvi-Kolhapuri/pen/rNPZabZ](https://codepen.io/Tanvi-Kolhapuri/pen/rNPZabZ).

